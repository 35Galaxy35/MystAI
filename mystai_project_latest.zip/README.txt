# MystAI — Latest Project
Ready-to-deploy web + backend. Legal pages included.

## Local
cd backend
npm ci
# .env (optional): OPENAI_API_KEY=..., OPENAI_MODEL=gpt-4o-mini
npm start
# open http://localhost:3000/

## Render Deploy
- Create Web Service from GitHub repo
- Start command: node backend/server.js
- Add env vars in dashboard (OPENAI_API_KEY/OPENAI_MODEL)
