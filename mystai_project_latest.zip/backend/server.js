// MystAI backend (Express)
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fetch = require('node-fetch');
const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors());
app.use(express.json());
app.use(express.static('frontend/public'));

app.get('/api/health', (req, res)=> res.json({status:'ok'}));

app.post('/api/analyze', upload.single('image'), async (req, res) => {
  try{
    const type = req.body.type || 'coffee';
    const question = req.body.question || '';
    const lang = req.body.lang || 'tr';

    if(process.env.OPENAI_API_KEY){
      const messages = [
        { role:'system', content: process.env.MYSTAI_SYSTEM_PROMPT || 'You are MystAI, a kind, insightful fortune teller. Keep it helpful and gentle.' },
        { role:'user', content:`Type: ${type}
Question: ${question}
Language: ${lang}
Give a warm, mystical yet modern reading in the requested language.`}
      ];
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method:'POST',
        headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
        body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages, max_tokens: 700, temperature: 0.9 })
      });
      const data = await resp.json();
      const text = (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) ? data.choices[0].message.content : JSON.stringify(data);
      return res.json({ source:'openai', text });
    }

    res.json({ source:'mock', text:`Demo: ${type} için kısa mistik yorum (OpenAI anahtarı eklenirse gerçek yorum gelecektir).` });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'server_error', message:e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('MystAI backend running on', PORT));
